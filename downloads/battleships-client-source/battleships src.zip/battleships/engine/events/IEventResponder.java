package battleships.engine.events;

/**
 *
 * @author Louis Bennette
 */
public interface IEventResponder {
    public void handleEvent(IEvent event);
}
